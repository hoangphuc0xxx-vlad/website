/**
 * FREESHION - Luxury Menswear Interactive Script
 */

document.addEventListener('DOMContentLoaded', () => {
  initCartDrawer();
  initPasswordToggle();
  initQuickView();
  initAdminChart();
  initAutoDismissToasts();
});

// Toast notification helper
function showToast(message, type = 'success') {
  const container = document.querySelector('.flash-container') || createToastContainer();
  const toast = document.createElement('div');
  toast.className = `flash-toast ${type}`;
  toast.innerHTML = `
    <span>${message}</span>
    <button onclick="this.parentElement.remove()" style="background:none;border:none;color:inherit;cursor:pointer;margin-left:12px;">✕</button>
  `;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(30px)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function createToastContainer() {
  const container = document.createElement('div');
  container.className = 'flash-container';
  document.body.appendChild(container);
  return container;
}

function initAutoDismissToasts() {
  const toasts = document.querySelectorAll('.flash-toast');
  toasts.forEach(t => {
    setTimeout(() => {
      t.style.opacity = '0';
      t.style.transform = 'translateX(30px)';
      setTimeout(() => t.remove(), 300);
    }, 4500);
  });
}

// Cart Drawer
function initCartDrawer() {
  const cartBtn = document.getElementById('openCartBtn');
  const closeBtn = document.getElementById('closeCartBtn');
  const overlay = document.getElementById('cartOverlay');
  const drawer = document.getElementById('cartDrawer');

  if (!drawer || !overlay) return;

  const openDrawer = () => {
    overlay.classList.add('active');
    drawer.classList.add('active');
    document.body.style.overflow = 'hidden';
  };

  const closeDrawer = () => {
    overlay.classList.remove('active');
    drawer.classList.remove('active');
    document.body.style.overflow = '';
  };

  if (cartBtn) cartBtn.addEventListener('click', openDrawer);
  if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
  overlay.addEventListener('click', closeDrawer);

  // Global trigger for add to cart buttons
  document.querySelectorAll('.btn-add-to-cart').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      const productId = btn.getAttribute('data-id');
      const size = btn.getAttribute('data-size') || 'L';
      const color = btn.getAttribute('data-color') || 'ĐEN';

      try {
        const res = await fetch('/api/cart/add', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ product_id: productId, size, color, quantity: 1 })
        });
        const data = await res.json();
        if (data.success) {
          updateCartUI(data);
          showToast(data.message, 'success');
          openDrawer();
        } else {
          showToast(data.message || 'Lỗi thêm giỏ hàng', 'error');
        }
      } catch (err) {
        console.error(err);
        showToast('Có lỗi xảy ra khi thêm vào giỏ hàng', 'error');
      }
    });
  });
}

function updateCartUI(data) {
  const badge = document.querySelector('.cart-badge');
  if (badge) badge.textContent = data.cart_count;

  const totalElems = document.querySelectorAll('.cart-total-amount');
  const formattedTotal = (data.cart_total || 0).toLocaleString('vi-VN') + ' ₫';
  totalElems.forEach(el => el.textContent = formattedTotal);

  const cartList = document.getElementById('cartDrawerItems');
  if (!cartList) return;

  if (!data.cart || data.cart.length === 0) {
    cartList.innerHTML = `<div style="text-align:center;padding:40px 0;color:#71717A;">Giỏ hàng của bạn đang trống</div>`;
    return;
  }

  cartList.innerHTML = data.cart.map((item, index) => `
    <div class="cart-item-row">
      <img src="${item.image_url}" alt="${item.name}" class="cart-item-img">
      <div class="cart-item-details">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-meta">Màu: ${item.color} | Size: ${item.size}</div>
        <div class="cart-item-price">${(item.price * item.quantity).toLocaleString('vi-VN')} ₫</div>
        <div style="display:flex;align-items:center;gap:10px;margin-top:6px;">
          <button onclick="updateCartItemQty(${index}, ${item.quantity - 1})" style="background:#27272A;border:none;color:#fff;width:24px;height:24px;border-radius:2px;cursor:pointer;">-</button>
          <span style="font-size:0.85rem;">${item.quantity}</span>
          <button onclick="updateCartItemQty(${index}, ${item.quantity + 1})" style="background:#27272A;border:none;color:#fff;width:24px;height:24px;border-radius:2px;cursor:pointer;">+</button>
          <button onclick="updateCartItemQty(${index}, 0)" style="background:none;border:none;color:#71717A;margin-left:auto;cursor:pointer;font-size:0.8rem;">Xóa</button>
        </div>
      </div>
    </div>
  `).join('');
}

async function updateCartItemQty(index, quantity) {
  try {
    const res = await fetch('/api/cart/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ index, quantity })
    });
    const data = await res.json();
    if (data.success) {
      updateCartUI(data);
    }
  } catch (e) {
    console.error(e);
  }
}

// Password toggle eye icon
function initPasswordToggle() {
  const toggleBtns = document.querySelectorAll('.toggle-password-btn');
  toggleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const input = btn.previousElementSibling || document.getElementById('authPassword');
      if (input && input.type === 'password') {
        input.type = 'text';
        btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>`;
      } else if (input) {
        input.type = 'password';
        btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`;
      }
    });
  });
}

// Quick View Modal
function initQuickView() {
  const modal = document.getElementById('quickViewModal');
  if (!modal) return;
  const modalClose = document.getElementById('closeQuickView');
  const modalBody = document.getElementById('quickViewContent');

  const closeModal = () => modal.classList.remove('active');
  if (modalClose) modalClose.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  document.querySelectorAll('.btn-quick-view').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      const id = btn.getAttribute('data-id');
      try {
        const res = await fetch(`/product/${id}`);
        const p = await res.json();
        if (p.name) {
          modalBody.innerHTML = `
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:36px;padding:36px;">
              <div style="aspect-ratio:3/4;overflow:hidden;background:#18181B;border-radius:2px;">
                <img src="${p.image_url}" alt="${p.name}" style="width:100%;height:100%;object-fit:cover;">
              </div>
              <div style="display:flex;flex-direction:column;justify-content:center;">
                <span style="font-size:0.75rem;letter-spacing:0.2em;color:#C5A880;text-transform:uppercase;">${p.badge || 'BỘ SƯU TẬP CAO CẤP'}</span>
                <h2 style="font-family:'Cormorant Garamond',serif;font-size:2.2rem;color:#fff;margin:8px 0 16px 0;">${p.name}</h2>
                <div style="font-size:1.4rem;color:#C5A880;font-weight:600;margin-bottom:20px;">
                  ${p.price.toLocaleString('vi-VN')} ₫
                  ${p.original_price ? `<span style="font-size:1rem;color:#71717A;text-decoration:line-through;margin-left:12px;">${p.original_price.toLocaleString('vi-VN')} ₫</span>` : ''}
                </div>
                <p style="color:#9E9EA8;font-size:0.95rem;line-height:1.7;margin-bottom:24px;">
                  ${p.description || 'Chế tác từ chất liệu thượng hạng, đường may thủ công chuẩn mực tôn vinh khí chất lịch lãm.'}
                </p>
                <div style="margin-bottom:20px;">
                  <div style="font-size:0.8rem;color:#71717A;text-transform:uppercase;margin-bottom:8px;">Màu sắc: <strong style="color:#fff;">${p.color || 'Đen'}</strong></div>
                  <div style="font-size:0.8rem;color:#71717A;text-transform:uppercase;margin-bottom:8px;">Kích cỡ sẵn có: <strong style="color:#fff;">${p.sizes || 'S, M, L, XL'}</strong></div>
                </div>
                <button class="btn-primary" onclick="addSingleProductToCart(${p.id}, '${p.color}', 'L')" style="justify-content:center;">
                  THÊM VÀO GIỎ HÀNG
                </button>
              </div>
            </div>
          `;
          modal.classList.add('active');
        }
      } catch (err) {
        console.error(err);
      }
    });
  });
}

async function addSingleProductToCart(productId, color, size) {
  try {
    const res = await fetch('/api/cart/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product_id: productId, size: size || 'L', color: color || 'ĐEN', quantity: 1 })
    });
    const data = await res.json();
    if (data.success) {
      updateCartUI(data);
      showToast(data.message, 'success');
      const modal = document.getElementById('quickViewModal');
      if (modal) modal.classList.remove('active');
      const drawer = document.getElementById('cartDrawer');
      const overlay = document.getElementById('cartOverlay');
      if (drawer && overlay) {
        overlay.classList.add('active');
        drawer.classList.add('active');
      }
    }
  } catch (err) {
    console.error(err);
  }
}

// Admin Chart Interactive Controls
function initAdminChart() {
  const btnRevenue = document.getElementById('chartToggleRev');
  const btnOrders = document.getElementById('chartToggleOrders');
  if (!btnRevenue || !btnOrders) return;

  const barPrev = document.getElementById('barPrevMonth');
  const barCurr = document.getElementById('barCurrMonth');
  const labelPrev = document.getElementById('valPrevMonth');
  const labelCurr = document.getElementById('valCurrMonth');
  const diffBadge = document.getElementById('diffBadge');

  btnRevenue.addEventListener('click', () => {
    btnRevenue.classList.add('active');
    btnOrders.classList.remove('active');
    if (barPrev && barCurr) {
      barPrev.style.height = '85%';
      barCurr.style.height = '4%';
      if (labelPrev) labelPrev.textContent = '4.180.000 ₫';
      if (labelCurr) labelCurr.textContent = '0 ₫';
      if (diffBadge) diffBadge.textContent = 'Giảm 100% so với tháng trước (toàn tháng).';
    }
  });

  btnOrders.addEventListener('click', () => {
    btnOrders.classList.add('active');
    btnRevenue.classList.remove('active');
    if (barPrev && barCurr) {
      barPrev.style.height = '75%';
      barCurr.style.height = '50%';
      if (labelPrev) labelPrev.textContent = '03 đơn';
      if (labelCurr) labelCurr.textContent = '02 đơn';
      if (diffBadge) diffBadge.textContent = '2 đơn mới trong tháng 10 đang chờ xử lý/giao hàng.';
    }
  });
}
